package com.example.loginpage;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.FrameLayout;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class dashboard extends AppCompatActivity {
FloatingActionButton log,voting,result;
FrameLayout vote1,result1,aboutus;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);
        log=findViewById(R.id.floatingActionButton4);
        result=findViewById(R.id.floatingActionButton2);
        voting=findViewById(R.id.floatingActionButton);
        vote1=findViewById(R.id.votes);
        result1=findViewById(R.id.result);
        aboutus=findViewById(R.id.aboout);





        result.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent me1=new Intent(getApplicationContext(),result.class);
                startActivity(me1);
            }
        });
        voting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent me=new Intent(getApplicationContext(),vote_candidate.class);
                startActivity(me);
            }
        });

        result1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent r=new Intent(getApplicationContext(),result.class);
                startActivity(r);
            }
        });
        aboutus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
Intent obj=new Intent(Intent.ACTION_VIEW);
obj.setData(Uri.parse("https://education.nationalgeographic.org/resource/why-voting-important/"));
startActivity(obj);
            }
        });
        vote1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent next=new Intent(getApplicationContext(), vote_candidate.class);
                startActivity(next);
            }
        });


        log.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {
                SharedPreferences myPrefs = getSharedPreferences("Activity",
                        MODE_PRIVATE);
                SharedPreferences.Editor editor = myPrefs.edit();
                editor.clear();
                editor.commit();
                //AppState.getSingleInstance().setLoggingOut(true);
                set(true);
//                Log.d("Now log out and start the activity login");
                Intent intent = new Intent(dashboard.this,
                        MainActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);

            }

        });


    }
    private void set ( boolean status){
        SharedPreferences sp = getSharedPreferences("LoginState",
                MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putBoolean("setLoggingOut", status);
        ed.commit();

    }


}


