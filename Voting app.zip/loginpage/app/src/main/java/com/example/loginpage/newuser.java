package com.example.loginpage;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class newuser extends AppCompatActivity {
    Button save;
    EditText name,email,phone,password,confirm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_newuser);
        save = findViewById(R.id.save_button);
        name = findViewById(R.id.editTextText);
        email = findViewById(R.id.editTextTextEmailAddress);
        phone = findViewById(R.id.editTextPhone);
        password = findViewById(R.id.editTextTextPassword);
        confirm = findViewById(R.id.editTextTextPassword2);

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                saving();
//                Toast.makeText(newuser.this, "SAVED", Toast.LENGTH_SHORT).show();
//                Intent back=new Intent(getApplicationContext(),MainActivity.class);
//                startActivity(back);
////


                        if(TextUtils.isEmpty(name.getText().toString())){
                            name.setError("Compulsory");
                        }
                        else if(TextUtils.isEmpty(email.getText().toString())){
                            email.setError("Compulsory");
                        }
                        else if(TextUtils.isEmpty(phone.getText().toString())){
                            phone.setError("Compulsory");
                        }
                        else if(TextUtils.isEmpty(password.getText().toString())){
                            password.setError("Compulsory");
                        }
                        else if(TextUtils.isEmpty(confirm.getText().toString())){
                            confirm.setError("Compulsory");
                        }
                        else{
                            saving();
                            Intent obj= new Intent(getApplicationContext(),MainActivity.class);
                            startActivity(obj);
                        }

            }
        });
    }
        public  void saving()
        {

            String url="https://kingrahood.000webhostapp.com/login.php";
            String user_name=name.getText().toString();
            String user_mail=email.getText().toString();
            String user_phone=phone.getText().toString();
            String user_password=password.getText().toString();
//            String user_name=name.getText().toString();
            StringRequest request=new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    Toast.makeText(getApplicationContext(), response.toString(), Toast.LENGTH_SHORT).show();
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(getApplicationContext(),"error="+error.getMessage().toString() ,Toast.LENGTH_SHORT).show();
                }

        }){
                @Nullable
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    Map<String,String> param=new HashMap<String,String>();
                    param.put("name",user_name);
                    param.put("mail",user_mail);
                    param.put("phone",user_phone);
                    param.put("password",user_password);
                    return  param;

                }
            };


            RequestQueue queue= Volley.newRequestQueue(newuser.this);
            queue.add(request);


        }
}