package com.example.loginpage;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.content.BroadcastReceiver;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.FrameLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class adminprofile2 extends AppCompatActivity {
    FloatingActionButton logout;
    ListView l1;
    FrameLayout list;
    TextView create,vote,result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adminprofile2);
        logout = findViewById(R.id.floatingActionButton9);
        create=findViewById(R.id.textView7);
        vote=findViewById(R.id.textViewnew);
        result=findViewById(R.id.textView9);
//        user=findViewById(R.id.userlist);
        list=findViewById(R.id.userlist);
        result.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent me1=new Intent(getApplicationContext(),result.class);
                startActivity(me1);
            }
        });

        vote.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent me=new Intent(getApplicationContext(),dashboard.class);
                startActivity(me);
            }
        });
        create.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//        Toast.makeText(getApplicationContext(),"open",Toast.LENGTH_SHORT).show();
        Intent next=new Intent(getApplicationContext(),com.example.loginpage.create.class);
        startActivity(next);
            }
        });
//
        list.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent next=new Intent(getApplicationContext(), lists.class);
                        startActivity(next);
                    }
                });
        logout.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {
                SharedPreferences myPrefs = getSharedPreferences("Activity",
                        MODE_PRIVATE);
                SharedPreferences.Editor editor = myPrefs.edit();
                editor.clear();
                editor.commit();
                //AppState.getSingleInstance().setLoggingOut(true);
                set(true);
//                Log.d("Now log out and start the activity login");
                Intent intent = new Intent(adminprofile2.this,
                        MainActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);

            }

        });


    }
        private void set ( boolean status){
            SharedPreferences sp = getSharedPreferences("LoginState",
                    MODE_PRIVATE);
            SharedPreferences.Editor ed = sp.edit();
            ed.putBoolean("setLoggingOut", status);
            ed.commit();
        }


    }
