package com.example.loginpage;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    Button forgot,login,user;
    EditText email,password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        email=findViewById(R.id.Address);
        password=findViewById(R.id.Password);
        forgot=findViewById(R.id.forgot);
        login=findViewById(R.id.log);
        user=findViewById(R.id.users);




        login.setOnClickListener(new View.OnClickListener() {
                                     @Override
                                     public void onClick(View view) {

                                         String email_value = email.getText().toString();
                                         String password_value = password.getText().toString();
                                         String url = "https://kingrahood.000webhostapp.com/valid.php";
//                                         String login_email = "goutam@gmail.com";
                                         Intent obj = new Intent(getApplicationContext(), adminprofile2.class);
                                         startActivity(obj);

//                                         String login_password = "goutam";
                                         StringRequest request = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {

                                             @Override
                                             public void onResponse(String response) {
//                                                 if (response.equals("success")) {
////                                                    Toast.makeText(getApplicationContext(),"succ",Toast.LENGTH_SHORT).show();
//
//                                                 } else {
//                                                     Toast.makeText(getApplicationContext(), response.toString(), Toast.LENGTH_SHORT).show();
//                                                 }
                                             }
                                         }, new Response.ErrorListener() {
                                             @Override
                                             public void onErrorResponse(VolleyError error) {

                                             }

                                         }) {
                                             @Nullable
                                             @Override
                                             protected Map<String, String> getParams() throws AuthFailureError {
                                                 Map<String, String> param = new HashMap<String, String>();
                                                 param.put("mail", email_value);
                                                 param.put("password", password_value);
                                                 return param;

                                             }

                                         };
                                         RequestQueue queue = Volley.newRequestQueue(MainActivity.this);
                                         queue.add(request);
                                     }

        });





        user.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            Intent obj1=new Intent(getApplicationContext(),newuser.class);
            startActivity(obj1);

            }
        });
        forgot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent forgot= new Intent(getApplicationContext(),forgot.class);
                startActivity(forgot);
            }
        });



    }
}