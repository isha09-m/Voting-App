package com.example.loginpage;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Adapter;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Spinner;

import java.net.URL;
import java.sql.Time;
import java.time.MonthDay;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import android.app.DatePickerDialog;
//import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.app.TimePickerDialog;
import android.graphics.Color;
//import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.github.dhaval2404.imagepicker.ImagePicker;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class create extends AppCompatActivity {
    Spinner voting, candidates;
    EditText date, end, stime, etime,e1,e2,e3,e4,n1;
    DatePickerDialog dialog;

    ArrayList<String> name = new ArrayList<>();
    ArrayAdapter<String> nameadp;
    RequestQueue requestQueue;
    FloatingActionButton f1,f2,f3,f4;
    Button send;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create);
//        voting = findViewById(R.id.vote);
//        candidates = findViewById(R.id.addcandidates);
//        f1=findViewById(R.id.floatingActionButton10);
//        f2=findViewById(R.id.floatingActionButton12);
//        f3=findViewById(R.id.floatingActionButton13);
//        f4=findViewById(R.id.floatingActionButton14);
        date = findViewById(R.id.startdate);
//        end = findViewById(R.id.endDate);
        stime = findViewById(R.id.startTime);
//        etime = findViewById(R.id.endTime);
        send=findViewById(R.id.upload);
        e1=findViewById(R.id.editTextText6);
        e2=findViewById(R.id.editTextText7);
        e3=findViewById(R.id.editTextText8);
        e4=findViewById(R.id.editTextText9);
        n1=findViewById(R.id.editTextText3);

        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent me= new Intent(getApplicationContext(),adminprofile2.class);
                startActivity(me);
            }
        });

////        f1.setOnClickListener(new View.OnClickListener() {
////            @Override
////            public void onClick(View view) {
////                ImagePicker.with(create.this)
////.galleryOnly()
////.crop() //Crop
////        image(Optional), Check Customization for more
////                option
//////.compress(1024) //Final image size
////        will be less than 1 MB(Optional)
//////.maxResultSize(1080, 1080) //Final
////        image resolution will be less than 1080 x
////        1080(Optional)
//                        .start();
//            }
//
//        });
//
//        f2.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                ImagePicker.with(create.this)
////.galleryOnly()
////.crop() //Crop
////        image(Optional), Check Customization for more
////                option
//////.compress(1024) //Final image size
////        will be less than 1 MB(Optional)
//////.maxResultSize(1080, 1080) //Final
////        image resolution will be less than 1080 x
////        1080(Optional)
//                        .start();
//            }
//        });
//
//        f3.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                ImagePicker.with(create.this)
////.galleryOnly()
////.crop() //Crop
////        image(Optional), Check Customization for more
////                option
//////.compress(1024) //Final image size
////        will be less than 1 MB(Optional)
//////.maxResultSize(1080, 1080) //Final
////        image resolution will be less than 1080 x
////        1080(Optional)
//                        .start();
//            }
//        });
//
//        f4.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                ImagePicker.with(create.this)
////.galleryOnly()
////.crop() //Crop
////        image(Optional), Check Customization for more
////                option
//////.compress(1024) //Final image size
////        will be less than 1 MB(Optional)
//////.maxResultSize(1080, 1080) //Final
////        image resolution will be less than 1080 x
////        1080(Optional)
//                        .start();
//            }
//        });
//
//        send.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                sending();
//            }
//        });


        date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final Calendar c = Calendar.getInstance();
                int mYear = c.get(Calendar.YEAR); // current year
                int mMonth = c.get(Calendar.MONTH); // current month
                int mDay = c.get(Calendar.DAY_OF_MONTH); // current day

                dialog=new DatePickerDialog(create.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
                        date.setText(i + "/" + (i1+1) + "/" +i2);}
                },mYear,mMonth, mDay);
                dialog.show();
            }

        });
//        end.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                final Calendar c = Calendar.getInstance();
//                int mYear = c.get(Calendar.YEAR); // current year
//                int mMonth = c.get(Calendar.MONTH); // current month
//                int mDay = c.get(Calendar.DAY_OF_MONTH); // current day
//
//                dialog=new DatePickerDialog(create.this, new DatePickerDialog.OnDateSetListener() {
//                    @Override
//                    public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
//                        date.setText(i + "/" + (i1+1) + "/" +i2);}
//                },mYear,mMonth, mDay);
//                dialog.show();
//
//            }
//        });
        stime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Calendar mcurrentTime = Calendar.getInstance();
                int hour = mcurrentTime.get(Calendar.HOUR_OF_DAY);
                int minute = mcurrentTime.get(Calendar.MINUTE);
                TimePickerDialog mtimepicker;
                mtimepicker= new TimePickerDialog(create.this, new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker timePicker, int i, int i1) {
                        stime.setText(i + ":" + i1);
                    }
                },hour,minute,true);
                mtimepicker.setTitle("select time");
                mtimepicker.show();
            }

        });
//        etime.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Calendar mcurrentTime = Calendar.getInstance();
//                int hour = mcurrentTime.get(Calendar.HOUR_OF_DAY);
//                int minute = mcurrentTime.get(Calendar.MINUTE);
//                TimePickerDialog mtimepicker;
//                mtimepicker= new TimePickerDialog(create.this, new TimePickerDialog.OnTimeSetListener() {
//                    @Override
//                    public void onTimeSet(TimePicker timePicker, int i, int i1) {
//                        stime.setText(i + ":" + i1);
//                    }
//                },hour,minute,true);
//                mtimepicker.setTitle("select time");
//                mtimepicker.show();
//            }
//
//        });





    }
public void sending(){
    String url="https://kingrahood.000webhostapp.com/createelection.php";
    String name=n1.getText().toString();
    String c1=e1.getText().toString();
    String c2 =e2.getText().toString();
    String c3 =e3.getText().toString();
    String c4 =e4.getText().toString();
    String sd =date.getText().toString();
    String ed =end.getText().toString();
    String st =stime.getText().toString();
    String et =etime.getText().toString();


    StringRequest request=new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
        @Override
        public void onResponse(String response) {
            Toast.makeText(getApplicationContext(),response.toString(),Toast.LENGTH_SHORT).show();


        }

    }, new Response.ErrorListener() {
        @Override
        public void onErrorResponse(VolleyError error) {
            Toast.makeText(getApplicationContext(),"error-"+error.getMessage().toString(),Toast.LENGTH_SHORT).show();
        }

    }){
        @Nullable
        @Override
        protected Map<String, String> getParams() throws AuthFailureError {
            Map<String,String> param=new HashMap<String,String>();
            param.put("elections",name);
            param.put("name1",c1);
            param.put("name2",c2);
            param.put("name3",c3);
            param.put("name4",c4);
            param.put("startdate",sd);
            param.put("enddate",ed);
            param.put("starttime",st);
            param.put("endtime",et);
            return param;
        }
    };
    RequestQueue queue= Volley.newRequestQueue(create.this);
    queue.add(request);


}
}
